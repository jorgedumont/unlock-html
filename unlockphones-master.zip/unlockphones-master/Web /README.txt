{\rtf1\ansi\ansicpg1252\cocoartf2511
\cocoatextscaling0\cocoaplatform0{\fonttbl\f0\fswiss\fcharset0 Helvetica;\f1\froman\fcharset0 Times-Roman;}
{\colortbl;\red255\green255\blue255;\red0\green0\blue233;}
{\*\expandedcolortbl;;\cssrgb\c0\c0\c93333;}
\paperw11900\paperh16840\margl1440\margr1440\vieww11260\viewh8400\viewkind0
\pard\tx566\tx1133\tx1700\tx2267\tx2834\tx3401\tx3968\tx4535\tx5102\tx5669\tx6236\tx6803\pardirnatural\partightenfactor0

\f0\fs24 \cf0 \
\
 - Test.html: pagina principal \
\
La hoja de estilos de la carpeta web es la que toma los estilos para el test.html, te dejo esto especificado ya que dentro de la carpeta unlockphones (pagina web inicial) hay otra hoja de estilos. \
\
\
\
PORTADA \
\
- Slider de im\'e1genes (adjunto dos links como ejemplo, he visto que tienen muy buena pinta) \
	{\field{\*\fldinst{HYPERLINK "https://codepen.io/viankakrisna/pen/JogZKO"}}{\fldrslt 
\f1 \cf2 \expnd0\expndtw0\kerning0
\ul \ulc2 \outl0\strokewidth0 \strokec2 https://codepen.io/viankakrisna/pen/JogZKO}}
\f1 \cf2 \expnd0\expndtw0\kerning0
\ul \ulc2 \outl0\strokewidth0 \strokec2 \
	{\field{\*\fldinst{HYPERLINK "https://codepen.io/supah/pen/zZaPeE"}}{\fldrslt https://codepen.io/supah/pen/zZaPeE}}
\f0 \cf0 \kerning1\expnd0\expndtw0 \ulnone \outl0\strokewidth0 \
- Footer (dentro de la carpeta IDEAS, imagen 1). Algo parecido o lo que te parezca a ti correcto \
- Apartado Contacto (dentro de la carpeta IDEAS, imagen 2). \
\
\
}