$("button").click(function() {
  swal("Success Message Title", "Well done, you pressed a button", "success")
});
